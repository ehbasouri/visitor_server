const accessTokenSecret = 'youraccesstokensecret';

module.exports = accessTokenSecret;